package com.example.imcsenac;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button)findViewById(R.id.button);

        button.setOnClickListener( v->{
            EditText altura = (EditText) findViewById(R.id.altura);
            EditText peso = (EditText) findViewById(R.id.peso);
            float infoAltura = Float.parseFloat(altura.getText().toString());
            float infoPeso = Float.parseFloat(peso.getText().toString());

            float pesoIdeal = calculaIMC(infoPeso,infoAltura);

            String res = "";

            if (pesoIdeal < 18.5){
                res = "1";
            }
            if (pesoIdeal >= 18.5 && pesoIdeal <= 24.9) {
                res = "2";
            }
            if (pesoIdeal >= 25.0 && pesoIdeal <= 29.9) {
                res = "3";
            }
            if (pesoIdeal >= 30.0 && pesoIdeal <= 34.9){
                res = "4";
            }
            if (pesoIdeal >= 35.0 && pesoIdeal <=39.9) {
                res = "5";
            }
            if (pesoIdeal >= 40.0) {
                res = "6";
            }

            Intent intent = new Intent(this, Tela2.class);
            intent.putExtra("info", String.format("%.1f",pesoIdeal));
            intent.putExtra("info2", res);
            startActivity(intent);
            finish();
        });
    }

    protected float calculaIMC(float peso, float altura){
        return peso/(altura*altura);
    }
}