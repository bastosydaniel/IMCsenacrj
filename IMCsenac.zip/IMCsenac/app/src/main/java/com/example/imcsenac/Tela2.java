package com.example.imcsenac;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

public class Tela2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        TextView destino = (TextView) findViewById(R.id.destino);
        TextView destino2 = (TextView) findViewById(R.id.destino2);
        ImageView imagem = (ImageView) findViewById(R.id.imagem2);

        Intent intent = getIntent();

        String pesoIdeal = intent.getStringExtra("info");
        destino.setText("Seu IMC é : "+pesoIdeal);
        String resultadoRecebido =  intent.getStringExtra("info2");
        switch (resultadoRecebido){
            case "1":
                resultadoRecebido = "Abaixo do Peso";
                imagem.setImageResource(R.drawable.abaixo);
                break;
            case "2":
                resultadoRecebido = "Peso Normal";
                imagem.setImageResource(R.drawable.normal);
                break;
            case "3":
                resultadoRecebido = "Acima do peso";
                imagem.setImageResource(R.drawable.acima);
                break;
            case "4":
                resultadoRecebido = "Obesidade Grau 1";
                imagem.setImageResource(R.drawable.obesidade1);
                break;
            case "5":
                resultadoRecebido = "Obesidade Grau 2";
                imagem.setImageResource(R.drawable.obesidade2);
                break;
            case "6":
                resultadoRecebido = "Obesidade Grau 3";
                imagem.setImageResource(R.drawable.obesidade3);
                break;
            default:
                resultadoRecebido = "você inseriu o valor errado!";
                imagem.setImageResource(R.drawable.imc);
        }

        destino2.setText(resultadoRecebido);



    }
}